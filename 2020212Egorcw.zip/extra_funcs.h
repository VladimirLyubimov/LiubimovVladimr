#pragma once
#include "structs.h"
#include <stdlib.h>
#include "plant_funcs.h"
#include "file_io.h"

void increasePlantArrSize(plant** arr, int size);
int addPlants(plant** arr, int* size);
void changePrice(plant* arr, int size);
void deletePlant(plant** arr, int* size);