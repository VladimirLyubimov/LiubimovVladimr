#pragma once
#include "structs.h"
#include <stdio.h>

int printPlantArray(plant* plant_arr, int size);
void printHeader();
void printTableLine();
void printHelp();
void printMarchMayPlants(plant* plant_arr, int size);
void printMenu();