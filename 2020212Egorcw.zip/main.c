#include <stdio.h>
#include <stdlib.h>
#include "structs.h"
#include "file_io.h"
#include "plant_funcs.h"
#include "console_io.h"
#include "extra_funcs.h"

int main() {
	plant* plants = NULL;
	int plants_size = 0;
	char filename[31];
	FILE* fout = NULL;

	printf("Input name of file (if the file already exists it must be correct):\n");
	gets(filename);
	printf("\033[2J\033[1;1H");
	FILE* fin = fopen(filename, "r");
	if(fin){
		fread(&plants_size, sizeof(int), 1, fin);
		for(int i = 0; i < plants_size; i++){
			increasePlantArrSize(&plants, plants_size+i);
			readPlant(plants+i, fin);
		}
		fclose(fin);
	}
	else{
		plants = NULL;
		plants_size = 0;
	}

	//printf("To see manual press 'h'.\n");
	char cmd;
	while(1){
		printMenu();
		printf("Input command:\n");
		scanf(" %c", &cmd);
		printf("\033[2J\033[1;1H");
		switch (cmd){
			case 'e': //exit
				printf("You decided to exit the programm.\nGoodbye!\n");
				if(plants){
					free(plants);
				}
				return 0;

			case 'h': {//print manual
				printHelp();
				break;
			}

			case '1': {//append in file
				if(addPlants(&plants, &plants_size)){
					printf("Unacceptable input data. Try again!\n");
					break;
				}
				fout = fopen(filename, "w");
				if(writePlantArray(plants, plants_size, fout)){
					printf("Error during file operations!\n");
				}

				printf("Elements successfully appended\n");
				fclose(fout);
				break;
			}

			case '4': {//print data
				if(!plants){
					printf("No contnet in database!. Append content first.\n");
					break;
				}
				printf("List of plants with their numbers in overall list which should be planted in March, April or May:\n");
				printMarchMayPlants(plants, plants_size);
				break;
			}

			case '2': {//print all data as table
				if(!plants){
					printf("No contnet in database!. Append content first.\n");
					break;
				}
				printHeader();
				printPlantArray(plants, plants_size);
				break;
			}
			
			case '3': {//change data
				if(!plants){
					printf("No contnet in database!. Append content first.\n");
					break;
				}
				changePrice(plants, plants_size);
				fout = fopen(filename, "w");
				if(writePlantArray(plants, plants_size, fout)){
					printf("Error during file operations!\n");
				}

				printf("Operation successfully completed\n");
				fclose(fout);
				break;
			}

			default: {
				printf("Unknown command. Please see list of commands in manual. To do this press 'h'.\n");
				break;
			}
		}
	}

	if(plants){
		free(plants);
	}

	return 0;
}