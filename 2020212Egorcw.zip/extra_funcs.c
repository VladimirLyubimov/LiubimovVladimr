#include "extra_funcs.h"

void increasePlantArrSize(plant** arr, int size){
	*arr = (plant*)realloc(*arr, (size+1)*sizeof(plant));
}

int addPlants(plant** arr, int* size){
	int n = 0;
	printf("Input amount of new plants:\n");
	scanf("%d", &n);
	if(!n){
		return 1;
	}

	*arr = (plant*)realloc(*arr, (*size+n)*sizeof(plant));
	for(int i = 0; i < n; i++){
		//increasePlantArrSize(arr, *size);
		if(createNewPlant((*arr) + (*size) + i)){
			return 1;
		}
	}

	*size += n;
	return 0;
}

void changePrice(plant* arr, int size){
	char plantname[31];
	int new_price = 0;
	printf("Input plant name:\n");
	scanf("%s", plantname);
	printf("Input new price:\n");
	scanf("%d", &new_price);

	int amount_of_change = 0;
	for (int i = 0; i < size; i++){
		if(strcmp(arr[i].m_name, plantname) == 0){
			arr[i].m_price = new_price;
			amount_of_change += 1;
		}
	}

	if(!amount_of_change){
		printf("Element with that name doesn't exist!\n");
	}
}

void deletePlant(plant** arr, int* size){
	char plantname[31];
	printf("Input plant name:\n");
	scanf("%s", plantname);

	int amount_of_change = 0;
	for (int i = 0; i < *size; i++){
		if(strcmp((*arr)[i].m_name, plantname) == 0){
			for(int j = i; j < *size-1; j++){
				initPlant(*arr + j, (*arr)[j+1].m_name, strlen((*arr)[j+1].m_name), (*arr)[j+1].m_time, (*arr)[j+1].m_amount, (*arr)[j+1].m_price);
			}
			*size -= 1;
			amount_of_change += 1;
		}
	}

	if(!amount_of_change){
		printf("Element with that name doesn't exist!\n");
		return;
	}

	*arr = (plant*)realloc(*arr, *size*sizeof(plant));
}