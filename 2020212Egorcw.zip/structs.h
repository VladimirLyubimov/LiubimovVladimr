#pragma once

typedef struct {
	char m_name[31];
	int m_time;
	int m_amount;
	int m_price;
} plant;